//
//  SupersonicIntegrationHelper
//  Supersonic
//
//  Created by Yotam Ohayon on 23/11/2015.
//  Copyright © 2015 Supersonic. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SupersonicIntegrationHelper : NSObject

+ (void)validateIntegration;

@end
