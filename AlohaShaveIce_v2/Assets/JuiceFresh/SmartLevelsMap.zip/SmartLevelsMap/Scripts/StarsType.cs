﻿
public enum StarsType
{
    Separated,
    Solid
}
