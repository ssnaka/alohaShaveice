﻿
public enum TranslationType
{
    Teleportation,
    Walk
}
