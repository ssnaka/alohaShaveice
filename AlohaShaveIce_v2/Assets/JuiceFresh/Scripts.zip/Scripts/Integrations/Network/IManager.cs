﻿public interface IManager {

}
