﻿using UnityEngine;
using System.Collections;


[System.Serializable]
public class CollectedIngredients
{
    public string name;
    public Sprite sprite;
    public bool check;
    public int count;

}


